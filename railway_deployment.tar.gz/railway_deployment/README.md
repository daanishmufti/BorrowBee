# BorrowBee Railway Deployment Package

## Files Included

### Core Application Files
- `main.py` - Application entry point
- `app.py` - Flask configuration
- `models.py` - Database models
- `routes.py` - Application routes
- `auth.py` - Authentication system
- `email_service.py` - Email notifications
- `database.py` - Database initialization

### Configuration Files
- `pyproject.toml` - Dependencies
- `railway.json` - Railway configuration
- `runtime.txt` - Python version
- `Procfile` - Process configuration

### Frontend Files
- `templates/` - HTML templates
- `static/` - CSS, JS, and images

## Environment Variables Required

Set these in Railway dashboard under Variables:

```
SESSION_SECRET=your-secure-random-key
GMAIL_EMAIL=your-email@gmail.com
GMAIL_APP_PASSWORD=your-gmail-app-password
```

The `DATABASE_URL` will be automatically set by Railway's PostgreSQL service.

## Deployment Steps

1. Upload all files to GitHub repository
2. Create new Railway project from GitHub repo
3. Add PostgreSQL database service
4. Set environment variables
5. Deploy automatically

Your BorrowBee app will be live at: https://your-app.railway.app